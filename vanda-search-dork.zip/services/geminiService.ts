
import { GoogleGenAI, Type } from "@google/genai";
import { DorkResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const generateAIDorks = async (userPrompt: string): Promise<DorkResult[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are VANDA, the ultimate cybernetic intelligence for OSINT and high-precision data extraction. 
      Your neural core is programmed to bypass surface-level filters. 
      
      Generate 5 elite Google Dorks for this objective: "${userPrompt}".
      
      Scope includes but is not limited to:
      - VULNERABILITIES: XSS, LFD, LFI, XSRF, CSRF, SQL Injection (Boolean, Blind), File Upload vulnerabilities.
      - TARGETS: Global Gov/Gob sites, Educational (.edu), Military (.mil/.army), and specialized Commerce (Jewelry, Fashion, Perfumes, Hotels, Event Tickets).
      - DATA TYPES: Backup files (.sql, .bkp), Password lists (.txt, .env), configuration files, database errors.
      
      Operators you MUST use: inurl:, intitle:, intext:, filetype:, site:, cache:, allintext:.
      
      Format your response as high-grade intelligence: specific, accurate, and powerful.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              query: { type: Type.STRING },
              description: { type: Type.STRING },
              category: { type: Type.STRING },
            },
            required: ["query", "description", "category"],
          },
        },
      },
    });

    const text = response.text.trim();
    return JSON.parse(text);
  } catch (error) {
    console.error("Neural Error in Vanda Core:", error);
    return [];
  }
};
